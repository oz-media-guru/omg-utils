systemctl stop xbmc
cp  -r  /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data/* /storage/.xbmc/userdata/
systemctl start xbmc
