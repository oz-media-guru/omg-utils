systemctl stop xbmc
mkdir /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data
cp /storage/.xbmc/userdata/*.xml /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data
mkdir /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data/addon_data/
mkdir /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data/addon_data/script.skinshortcuts
cp /storage/.xbmc/userdata/addon_data/script.skinshortcuts/* /storage/.xbmc/userdata/addon_data/plugin.program.smartdns/data/addon_data/script.skinshortcuts
systemctl start xbmc
